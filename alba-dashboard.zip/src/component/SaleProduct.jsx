const SaleProduct = () =>{
    return(
        <>
            <div className=" w-[345px] h-[418px]">
                <div className=" w-[350px] h-[230px]">
                    <img src="" alt="" />
                </div>
                <div className=" text-lg text-yellow">
                    {}
                </div>
                <div>

                </div>
                <div>

                </div>
            </div>
        </>
    )
}

export default SaleProduct;