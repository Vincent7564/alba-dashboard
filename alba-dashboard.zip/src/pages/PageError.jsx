const PageError = () =>{
    return(
        <>

        </>
    );
}

export default PageError;